package br.com.edu.tutstuts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutsTutsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutsTutsApplication.class, args);
	}

}
